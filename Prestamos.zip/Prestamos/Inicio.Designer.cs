﻿namespace Prestamos
{
    partial class Inicio
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menu = new System.Windows.Forms.MenuStrip();
            this.menuempleado = new FontAwesome.Sharp.IconMenuItem();
            this.menusucursal = new FontAwesome.Sharp.IconMenuItem();
            this.menucliente = new FontAwesome.Sharp.IconMenuItem();
            this.menudepartamento = new FontAwesome.Sharp.IconMenuItem();
            this.MenuPrestamo = new FontAwesome.Sharp.IconMenuItem();
            this.menudetalleprestamo = new FontAwesome.Sharp.IconMenuItem();
            this.menuacercade = new FontAwesome.Sharp.IconMenuItem();
            this.menuTitulo = new System.Windows.Forms.MenuStrip();
            this.label1 = new System.Windows.Forms.Label();
            this.menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuempleado,
            this.menusucursal,
            this.menucliente,
            this.menudepartamento,
            this.MenuPrestamo,
            this.menudetalleprestamo,
            this.menuacercade});
            this.menu.Location = new System.Drawing.Point(0, 62);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(1370, 56);
            this.menu.TabIndex = 0;
            this.menu.Text = "menuStrip1";
            this.menu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menu_ItemClicked_1);
            // 
            // menuempleado
            // 
            this.menuempleado.IconChar = FontAwesome.Sharp.IconChar.UserCog;
            this.menuempleado.IconColor = System.Drawing.Color.Black;
            this.menuempleado.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.menuempleado.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.menuempleado.Name = "menuempleado";
            this.menuempleado.Size = new System.Drawing.Size(120, 52);
            this.menuempleado.Text = "Empleado";
            // 
            // menusucursal
            // 
            this.menusucursal.IconChar = FontAwesome.Sharp.IconChar.HouseUser;
            this.menusucursal.IconColor = System.Drawing.Color.Black;
            this.menusucursal.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.menusucursal.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.menusucursal.Name = "menusucursal";
            this.menusucursal.Size = new System.Drawing.Size(111, 52);
            this.menusucursal.Text = "Sucursal";
            // 
            // menucliente
            // 
            this.menucliente.IconChar = FontAwesome.Sharp.IconChar.User;
            this.menucliente.IconColor = System.Drawing.Color.Black;
            this.menucliente.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.menucliente.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.menucliente.Name = "menucliente";
            this.menucliente.Size = new System.Drawing.Size(104, 52);
            this.menucliente.Text = "Cliente";
            // 
            // menudepartamento
            // 
            this.menudepartamento.IconChar = FontAwesome.Sharp.IconChar.DollyFlatbed;
            this.menudepartamento.IconColor = System.Drawing.Color.Black;
            this.menudepartamento.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.menudepartamento.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.menudepartamento.Name = "menudepartamento";
            this.menudepartamento.Size = new System.Drawing.Size(143, 52);
            this.menudepartamento.Text = "Departamento";
            // 
            // MenuPrestamo
            // 
            this.MenuPrestamo.IconChar = FontAwesome.Sharp.IconChar.Page4;
            this.MenuPrestamo.IconColor = System.Drawing.Color.Black;
            this.MenuPrestamo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.MenuPrestamo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuPrestamo.Name = "MenuPrestamo";
            this.MenuPrestamo.Size = new System.Drawing.Size(117, 52);
            this.MenuPrestamo.Text = "Prestamo";
            // 
            // menudetalleprestamo
            // 
            this.menudetalleprestamo.IconChar = FontAwesome.Sharp.IconChar.AddressCard;
            this.menudetalleprestamo.IconColor = System.Drawing.Color.Black;
            this.menudetalleprestamo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.menudetalleprestamo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.menudetalleprestamo.Name = "menudetalleprestamo";
            this.menudetalleprestamo.Size = new System.Drawing.Size(153, 52);
            this.menudetalleprestamo.Text = "DetallePrestamo";
            // 
            // menuacercade
            // 
            this.menuacercade.IconChar = FontAwesome.Sharp.IconChar.InfoCircle;
            this.menuacercade.IconColor = System.Drawing.Color.Black;
            this.menuacercade.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.menuacercade.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.menuacercade.Name = "menuacercade";
            this.menuacercade.Size = new System.Drawing.Size(122, 52);
            this.menuacercade.Text = "Acerca de ";
            // 
            // menuTitulo
            // 
            this.menuTitulo.AutoSize = false;
            this.menuTitulo.BackColor = System.Drawing.Color.Blue;
            this.menuTitulo.Location = new System.Drawing.Point(0, 0);
            this.menuTitulo.Name = "menuTitulo";
            this.menuTitulo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuTitulo.Size = new System.Drawing.Size(1370, 62);
            this.menuTitulo.TabIndex = 1;
            this.menuTitulo.Text = "menuStrip2";
            this.menuTitulo.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip2_ItemClicked);
            this.menuTitulo.RightToLeftChanged += new System.EventHandler(this.label1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Blue;
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Location = new System.Drawing.Point(217, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(272, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sistema de Prestamo";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.menuTitulo);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.MenuStrip menuTitulo;
        private FontAwesome.Sharp.IconMenuItem menuempleado;
        private System.Windows.Forms.Label label1;
        private FontAwesome.Sharp.IconMenuItem menusucursal;
        private FontAwesome.Sharp.IconMenuItem menucliente;
        private FontAwesome.Sharp.IconMenuItem menudepartamento;
        private FontAwesome.Sharp.IconMenuItem MenuPrestamo;
        private FontAwesome.Sharp.IconMenuItem menudetalleprestamo;
        private FontAwesome.Sharp.IconMenuItem menuacercade;
    }
}

